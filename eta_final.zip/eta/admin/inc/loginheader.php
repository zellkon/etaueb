<?php 
header('Cache-Control: no-store, no-chache, must-revallidate');
header("Cache-Control: pre-check=0, post-check=0, max-age=0");
header("Pragma: no-cache");
header("Expires: Mon, 6 Dec 1977 00:00:00 GMT");
header("Last-Modified:". gmdate("D, d M Y H:i:s". " GMT"));
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link rel="stylesheet" href="css/mainadmin.css"/>
</head>
<body>
<div class="site-wrapper">
	
	<div class="header">
		<div class="container">
			<div class="header-img">
				<h1>Header image here</h1>
			</div>
		</div>
	</div>